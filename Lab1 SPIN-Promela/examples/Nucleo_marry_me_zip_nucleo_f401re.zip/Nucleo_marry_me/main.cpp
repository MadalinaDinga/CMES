
 #include "mbed.h"
 #include "buzzer.h"
 
 Beep buzzer(D8);//(PTC2);
DigitalOut myledD15(D15); 
 
void ask() {
    int r = rand() %2;
    buzzer.beep(1000,0.1); 
    if(r == 0){
        intern();
    }else(
        answer();
    )
}

void interm(){
    wait(3.0);
    ask();
}


void answer() {
    myledD15 = 1;
}
 
 int main() {
    ask();
 }