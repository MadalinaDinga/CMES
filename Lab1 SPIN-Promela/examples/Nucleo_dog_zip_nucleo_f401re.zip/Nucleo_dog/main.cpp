
 #include "mbed.h"
 #include "buzzer.h"
 
 Beep buzzer(D8);//(PTC2);
DigitalOut myledD15(D15); 
 
void seesCat() {
    wait(3.0);
    for (int i=0;i<3;i++) {
       buzzer.beep(1000,0.1);
       wait(1);
    }
}

void seesHuman() {
    wait(6.0);
    for (int i=0;i<5;i++) {
    myledD15 = 1;
    wait(0.5);
    myledD15 = 0;
    wait(0.5);
    }
}
 
 int main() {

    while(1)
    {
        int r = rand() % 2;
        if (r==0) {seesCat();}
        else {seesHuman();}
    }
 }