#include "mbed.h"


DigitalOut myledD15(D15); 
DigitalOut myledD14(D14); 
DigitalOut myledD8(D9); 
DigitalOut myledD9(D8); 

#define DEBUG 1
#define STATE_IDLE 0
#define STATE_1 1
#define STATE_2 2
#define STATE_3 3


int fsm_state; // our state variable
Serial pc(USBTX, USBRX);

void setup() {
  if(DEBUG){  
  pc.printf(" Serial communication started:");  
 }
 fsm_state = STATE_IDLE; // state variable initialization
}
 void loop(){

 switch(fsm_state) { // start of switch case
    case STATE_IDLE:
      //do instructions in STATE_IDLE
       wait(1.0);       
       if(DEBUG){           
            pc.printf(" I am IDLE \n");  
        }
       fsm_state = STATE_1;
       myledD15 = 1;
       myledD9 = 0;
       break;

     case STATE_1:
        //do instructions in STATE_1      
         wait(1.0); 
        if(DEBUG){
             pc.printf("I am in STATE_1 \n");
        }
        fsm_state = STATE_2;
        myledD14 = 1;
        myledD15 = 0;
        break;

         case STATE_2:
        //do instructions in STATE_2       
        wait(1.0); 
        if(DEBUG){
         pc.printf("I am in STATE_2 \n");
        }
        fsm_state = STATE_3;
        myledD8 = 1;
        myledD14 = 0;
        break;

        case STATE_3:
            //do instructions in STATE_3           
            wait(1.0); 
            if(DEBUG){
                 pc.printf("I am in STATE_3 \n ");
            }
            fsm_state = STATE_IDLE;
            myledD9 = 1;
            myledD8 = 0;
            break;

         }//end of switch case
}// end of loop()

 

int main() {
    while(1) {
        loop();       
    }
}
