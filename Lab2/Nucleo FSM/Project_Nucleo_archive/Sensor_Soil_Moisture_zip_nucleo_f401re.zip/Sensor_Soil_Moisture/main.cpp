#include "mbed.h"
Serial pc(USBTX, USBRX);
int main() {
    AnalogIn led(A0);
    
    while(1) {
       pc.printf(" \n Soil moisture humidity: %f ", led.read(),"\n");  
        wait(1.0);
    }
}
