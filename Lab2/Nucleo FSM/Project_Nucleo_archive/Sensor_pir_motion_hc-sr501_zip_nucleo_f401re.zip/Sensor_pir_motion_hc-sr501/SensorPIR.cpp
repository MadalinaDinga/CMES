#include "SensorPIR.h"

/*Defines*/
Serial UARTPIR(USBTX, USBRX);
DigitalOut dout(LED1);
DigitalIn enable1(D2);
//DigitalIn enable2(D1);
//DigitalIn enable3(D2);
//DigitalIn enable4(D3);

/*Functions*/
int GetPersonStatus(int RoomPrescence) {
    bool print = 0;
    bool RoomStatus = 0;   
    UARTPIR.baud(115200);
    wait(2); //Wait for sensor to take snap shot of still room
    
    switch(RoomPrescence)
    {
      case 1:
            if(enable1==1 /*|| enable2==1 || enable3==1 || enable4==1*/)
            {
                RoomStatus = 1;
                dout=1;
                if(print == 0)
                {
                    UARTPIR.printf("Presence detected \n\r");
                    print = 1;
                }
            }
            else
            {
                RoomStatus = 0;
                dout=0;
                if(print == 1)
                {
                    UARTPIR.printf("No presence detected\n\r");
                    print = 0;
                }
            }
            break;
            
        case 2:
        /*ADD NEW ROOM*/
            break;
            
        default:
        /*Do Nothing*/
            break;
    }
    return RoomStatus;
}
