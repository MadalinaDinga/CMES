#include "mbed.h"
#include "SensorPIR.h"
 
int main() {
    while(1)
    {
        GetPersonStatus(1);
    }
}
