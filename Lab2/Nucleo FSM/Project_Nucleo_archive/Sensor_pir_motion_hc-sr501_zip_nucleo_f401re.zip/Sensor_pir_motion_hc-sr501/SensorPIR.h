#include "mbed.h"

/*Extern Defines*/

/*Extern Variables*/

/*Extern Functions*/
extern int GetPersonStatus(int RoomPrescence);