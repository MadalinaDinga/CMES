
/** class to make sound with a buzzer, based on a PwmOut
 *   The class use a timeout to switch off the sound  - it is not blocking while making noise
 *
 * Example:
 * @code
 * // Beep with 1Khz for 0.5 seconds
*/
 #include "mbed.h"
 #include "buzzer.h"
 
 Beep buzzer(D3);//(PTC2);
 
 int main() {
       
   buzzer.beep(1000,0.5);   
   wait(2.0); 
   buzzer.beep(1000,0.5);   
   wait(2.0); 
   buzzer.beep(1000,0.5);   
 }

 