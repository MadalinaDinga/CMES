//*******************************************************
 // Here is a sample code usage
//********************************************************* 
#include "hcsr04.h"
                 //triger, echo
HCSR04  usensor(D15,D14);
//VCC to 5V

Serial pc(USBTX, USBRX);
int main()
{
    unsigned char count=0;
    while(1) {
        usensor.start();
        wait_ms(500); 
        int dist=usensor.get_dist_cm();
        pc.printf(" cm:%d ",dist);     
        count++;         
    }
}