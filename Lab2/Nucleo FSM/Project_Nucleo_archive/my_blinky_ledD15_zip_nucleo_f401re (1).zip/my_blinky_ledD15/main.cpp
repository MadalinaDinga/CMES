#include "mbed.h"

DigitalOut myledD15(D15);

int main() {
    while(1) {
        myledD15 = 1;
        wait(1.0);//1 second
        myledD15 = 0;
        wait(0.3);
    }
}