#include "mbed.h"

DigitalOut myledD15(D15); //rosu
DigitalOut myledD14(D14); //verde
DigitalIn pb(D7);

//function to perform bitwise inversion
int invert(int value){
    if (value == 0) 
        return 1;
    else 
        return 0;    
}

int main() {
    pb.mode(PullUp);    
    int valuePB;
    //masina are verde (led rosu stins, led verde aprind)
    myledD15 =0;
    myledD14 =1;
    
    while(1) {
        //varianta 1 = aprins/stins led
        //myledD15 =1;
        //wait(0.2); // 200 ms
        //myledD15 =0;        
        //wait(1.0); // 1 sec
        
        //varianta 2 = click la pb sa se stinga becul
        //myledD15=pb;
        
        //varianta 3 = click la pb sa se aprinda becul
         // pushbuttons pull low when pressed, so invert them
        valuePB = invert(pb.read());
        if(valuePB) { //apasa pe buton pieton, adica doreste sa traverseze           
            wait(6.0); //asteapta 6 secunde pana se face galben/albastru
            //se face rosu, se stinge verde            
            myledD15 =1;
            myledD14 =0;
            wait(10.0); //se asteapta sa treaca pietonii                                   
            //se face verde la masini pana cand se apasa din nou butonul de catre un pieton
            myledD15 =0;
            myledD14 =1;        
         }
    }
}
