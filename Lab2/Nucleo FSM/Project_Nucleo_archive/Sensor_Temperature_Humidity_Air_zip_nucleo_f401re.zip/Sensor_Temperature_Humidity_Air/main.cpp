

#include "DHT11.h"


PinName myledD15(D15);
// Humidity sensor
DHT11 d(myledD15);

Serial pc(USBTX, USBRX);


int main() {
    int state;

    while(1) {
        
        
        state = d.readData();
        
        
        if (state != DHT11::OK) {
            
           printf("\n Error: %d", state);
        } else {
            
            printf("\n T: %dC, H: %d%%", d.readTemperature(), d.readHumidity());
        }
        
         //pc.printf("\n T: %dC, H: %d%%", d.readTemperature(), d.readHumidity());  
          
       
        wait(2.0);

        
    }
}